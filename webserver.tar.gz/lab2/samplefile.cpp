#include <iostream>
#include <stdlib.h>
#include <string>

int main()
{
	std::cout <<"hello!" << std::endl;

	//parse input params

	std:: port_num = atoi(argv[1]);

	//where all of your stuff is
	// localhost:50000/hello.html
	// hello.html should be in content_folder
	std::string content_folder = argv[2];
	// cout checks

	// socket stuff

	// listen?

	//process get request

	// ?????serve files or something

}
